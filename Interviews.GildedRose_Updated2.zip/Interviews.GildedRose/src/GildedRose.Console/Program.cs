﻿using System.Collections.Generic;

namespace GildedRose.Console
{
    public class Program
    {
        public IList<Item> Items;
        static void Main(string[] args)
        {
            System.Console.WriteLine("OMGHAI!");

            var app = new Program()
            {
                Items = new List<Item>
                                          {
                                              new Item {Name = "+5 Dexterity Vest", SellIn = 10, Quality = 20},
                                              new Item {Name = "Aged Brie", SellIn = 2, Quality = 0},
                                              new Item {Name = "Elixir of the Mongoose", SellIn = 5, Quality = 7},
                                              new Item {Name = "Sulfuras, Hand of Ragnaros", SellIn = 0, Quality = 80},
                                              new Item
                                                  {
                                                      Name = "Backstage passes to a TAFKAL80ETC concert",
                                                      SellIn = 15,
                                                      Quality = 20
                                                  },
                                              new Item {Name = "Conjured Mana Cake", SellIn = 3, Quality = 6}
                                          }

            };

            app.UpdateQuality();

            System.Console.WriteLine("Press any key to exit...");

        }

        public void UpdateQuality()
        {
            foreach (Item item in this.Items)
            {
                UpdateItem(item);

                // The quality of an item is never more than 50.
                item.Quality = System.Math.Min(50, item.Quality);

                // The quality of an item is never negative.
                item.Quality = System.Math.Max(0, item.Quality);
            }
        }

        public void UpdateItem(Item item)
        {
            switch (item.Name)
            {
                case "Aged Brie":

                    System.Console.WriteLine("Updating the item 'Aged Brie'");

                    // Aged brie increases in quality the older it gets
                    item.Quality++;
                    item.SellIn--;
                    break;

                case "Sulfuras, Hand of Ragnaros":
                    System.Console.WriteLine("Updating the item 'Sulfuras, Hand of Ragnaros'");
                    System.Console.WriteLine("As 'Sulfuras, Hand of Ragnaros' being a legendary item, legendary items never decrease in quality and never need to be sold.");
                    break;

                case "Backstage passes to a TAFKAL80ETC concert":

                    System.Console.WriteLine("Updating the item 'Backstage passes to a TAFKAL80ETC concert'");
                    item.SellIn--;

                    // "Backstage passes", like aged brie, increases in Quality as it's SellIn value approaches
                    if (item.SellIn > 10)
                    {
                        item.Quality++;
                    }

                    // Quality increases by 2 when there are 10 days or less
                    if (item.SellIn <= 10)
                    {
                        item.Quality += 2;
                    }

                    // Quality increases by 3 when there are 5 days or less
                    if (item.SellIn <= 5)
                    {
                        item.Quality++;
                    }

                    // Quality drops to 0 after the concert
                    if (item.SellIn < 0)
                    {
                        item.Quality = 0;
                    }
                    break;

                case "Conjured Mana Cake":

                    System.Console.WriteLine("Updating the item 'Conjured Mana Cake'");

                    // "Conjured" items degrade in Quality twice as fast as normal items
                    item.SellIn--;
                    item.Quality -= 2;

                    break;

                default:
                    
                    // At the end of each day our system lowers both values for every item
                    item.SellIn--;
                    item.Quality--;

                    // Once the sell by date has passed, Quality degrades twice as fast
                    if (item.SellIn < 0)
                    {
                        item.Quality--;
                    }

                    break;
            }
        }

    }

    public class Item
    {
        public string Name { get; set; }

        public int SellIn { get; set; }

        public int Quality { get; set; }
    }
}