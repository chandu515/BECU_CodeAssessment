﻿using System;
namespace GildedRose.Console.GuildedRose.Tests.Features
{
    using TechTalk.SpecFlow;


    [System.CodeDom.Compiler.GeneratedCodeAttribute("TechTalk.SpecFlow", "1.9.0.77")]
    [System.Runtime.CompilerServices.CompilerGeneratedAttribute()]
    [NUnit.Framework.TestFixtureAttribute()]
    [NUnit.Framework.DescriptionAttribute("Update Inventory")]
    public partial class UpdateInventoryFeature
    {

        private static TechTalk.SpecFlow.ITestRunner testRunner;

#line 1 "UpdateInventory.feature"
#line hidden

        [NUnit.Framework.TestFixtureSetUpAttribute()]
        public virtual void FeatureSetup()
        {
            testRunner = TechTalk.SpecFlow.TestRunnerManager.GetTestRunner();
            TechTalk.SpecFlow.FeatureInfo featureInfo = new TechTalk.SpecFlow.FeatureInfo(new System.Globalization.CultureInfo("en-US"), "Update Inventory", "As an inn keeper\r\nI want the system to automatically update item quality and sell" +
                    " by dates\r\nSo that I can keep track of items", ProgrammingLanguage.CSharp, ((string[])(null)));
            testRunner.OnFeatureStart(featureInfo);
        }

        [NUnit.Framework.TestFixtureTearDownAttribute()]
        public virtual void FeatureTearDown()
        {
            testRunner.OnFeatureEnd();
            testRunner = null;
        }

        [NUnit.Framework.SetUpAttribute()]
        public virtual void TestInitialize()
        {
        }

        [NUnit.Framework.TearDownAttribute()]
        public virtual void ScenarioTearDown()
        {
            testRunner.OnScenarioEnd();
        }

        public virtual void ScenarioSetup(TechTalk.SpecFlow.ScenarioInfo scenarioInfo)
        {
            testRunner.OnScenarioStart(scenarioInfo);
        }

        public virtual void ScenarioCleanup()
        {
            testRunner.CollectScenarioErrors();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Quality reduces each day")]
        public virtual void QualityReducesEachDay()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Quality reduces each day", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with quality of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 9", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Sell by date reduces each day")]
        public virtual void SellByDateReducesEachDay()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Sell by date reduces each day", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with a sell in of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a sell in of 9", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Quality degrades twice as fast once the sell by date has passed")]
        public virtual void QualityDegradesTwiceAsFastOnceTheSellByDateHasPassed()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Quality degrades twice as fast once the sell by date has passed", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with a sell in of 0 and a quality of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 8", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Quality of an item is never negative")]
        public virtual void QualityOfAnItemIsNeverNegative()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Quality of an item is never negative", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with a sell in of 0 and a quality of 0", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 0", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Aged Brie increases in quality the older it gets")]
        public virtual void AgedBrieIncreasesInQualityTheOlderItGets()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Aged Brie increases in quality the older it gets", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Aged Brie\" and a quality of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 11", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Quality of an item is never more than 50")]
        public virtual void QualityOfAnItemIsNeverMoreThan50()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Quality of an item is never more than 50", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Aged Brie\" and a quality of 50", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 50", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Legendary items never decrease in quality")]
        public virtual void LegendaryItemsNeverDecreaseInQuality()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Legendary items never decrease in quality", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Sulfuras, Hand of Ragnaros\" and a quality of 50", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 50", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Legendary items never need to be sold")]
        public virtual void LegendaryItemsNeverNeedToBeSold()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Legendary items never need to be sold", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Sulfuras, Hand of Ragnaros\" and a sell in of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a sell in of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Backstage passes increase in quality slowly when concert date is far away")]
        public virtual void BackstagePassesIncreaseInQualitySlowlyWhenConcertDateIsFarAway()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Backstage passes increase in quality slowly when concert date is far away", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Backstage passes to a TAFKAL80ETC concert\", a quality of 1" +
                               "0 and a sell in of 20", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 11", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Backstage passes increase in quality faster when concert date is near")]
        public virtual void BackstagePassesIncreaseInQualityFasterWhenConcertDateIsNear()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Backstage passes increase in quality faster when concert date is near", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Backstage passes to a TAFKAL80ETC concert\", a quality of 1" +
                               "0 and a sell in of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 12", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Backstage passes increase in quality fastest when concert is very near")]
        public virtual void BackstagePassesIncreaseInQualityFastestWhenConcertIsVeryNear()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Backstage passes increase in quality fastest when concert is very near", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Backstage passes to a TAFKAL80ETC concert\", a quality of 1" +
                               "0 and a sell in of 5", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 13", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Backstage passes have no value after a concert")]
        public virtual void BackstagePassesHaveNoValueAfterAConcert()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Backstage passes have no value after a concert", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Backstage passes to a TAFKAL80ETC concert\", a quality of 1" +
                               "0 and a sell in of 0", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 0", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }

        [NUnit.Framework.TestAttribute()]
        [NUnit.Framework.DescriptionAttribute("Conjured items degrade in quality twice as fast")]
        public virtual void ConjuredItemsDegradeInQualityTwiceAsFast()
        {
            TechTalk.SpecFlow.ScenarioInfo scenarioInfo = new TechTalk.SpecFlow.ScenarioInfo("Conjured items degrade in quality twice as fast", ((string[])(null)));
            this.ScenarioSetup(scenarioInfo);
            testRunner.Given("an item with the name \"Conjured water\" and a quality of 10", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Given ");
            testRunner.When("the system updates the inventory", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "When ");
            testRunner.Then("the item should have a quality of 8", ((string)(null)), ((TechTalk.SpecFlow.Table)(null)), "Then ");
            this.ScenarioCleanup();
        }
    }
}

